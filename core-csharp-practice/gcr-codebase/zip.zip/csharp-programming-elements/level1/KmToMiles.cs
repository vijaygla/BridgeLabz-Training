using System;

class KmToMiles
{
    static void Main()
    {
        double km = 10.8;
        double miles = km / 1.6;

        Console.WriteLine("The distance " + km + " km in miles is " + miles);
    }
}
