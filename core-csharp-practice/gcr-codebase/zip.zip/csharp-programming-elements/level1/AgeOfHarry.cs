using System;

class AgeOfHarry
{
    static void Main()
    {
        int birthYear = 2000;
        int currentYear = 2024;
        int age = currentYear - birthYear;

        Console.WriteLine("Harry's age in 2024 is " + age);
    }
}
