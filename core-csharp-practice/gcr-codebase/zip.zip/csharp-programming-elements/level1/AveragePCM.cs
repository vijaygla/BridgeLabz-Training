using System;

class AveragePCM
{
    static void Main()
    {
        int m = 94, p = 95, c = 96;
        double average = (m + p + c) / 3.0;

        Console.WriteLine("Sam’s average pcm speed: " + average);
    }
}

